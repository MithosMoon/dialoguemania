DialogueMania by Mithos Moon

MIT Licence


This addon uses Nodes with unique Nodes (%) with Godot 3.5 or higher.
Put The DialogueMania folder into your addons folder.
If you don't have an addon folder, create one inside your project folder.

This Dialogue System is timer driven, but can easily be pimped up with buttons.
For scalebility set stretch mode to vieport and aspect to keep in the project settings.

All the text is written into the Array inside Textblatt.gd

Have fun :)
